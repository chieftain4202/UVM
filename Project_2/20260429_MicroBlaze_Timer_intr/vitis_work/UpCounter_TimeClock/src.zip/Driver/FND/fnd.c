#include "fnd.h"

uint16_t fndNumData = 0;
int dotpoint;

void FND_SetComPort(GPIO_Typedef_t *FND_Port, uint32_t Seg_Pin, int OnOff) {

	GPIO_WritePin(FND_Port, Seg_Pin, OnOff);
}

void FND_DispDigit() {

	static uint8_t fndDigState = 0;
	fndDigState = (fndDigState + 1) % 4;

	switch (fndDigState) {
	case 0:
		FND_DispDigit_1();
		break;
	case 1:
		FND_DispDigit_10();
		break;
	case 2:
		FND_DispDigit_100();
		break;
	case 3:
		FND_DispDigit_1000();
		break;
	default:
		FND_DispDigit_1();
		break;
	}
}

void FND_Init() {
	// GPIO ����, GPIOA0,1,2,3 COM ����
	GPIO_SetMode(GPIOA,
	FND_COM_DIG_1 | FND_COM_DIG_2 | FND_COM_DIG_3 | FND_COM_DIG_4,
	OUTPUT);
	// GPIO ����, GPIOB seg
	GPIO_SetMode(GPIOB, SEG_PIN_A | SEG_PIN_B | SEG_PIN_C | SEG_PIN_D,
	OUTPUT);
	GPIO_SetMode(GPIOB, SEG_PIN_E | SEG_PIN_F | SEG_PIN_G | SEG_PIN_DP,
	OUTPUT);
}

void FND_DispDigit_1() {
	uint16_t fndFont[16] = { 0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8,
			0x80, 0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e };
	//num �ڸ��� �и�
	uint16_t digitData1 = fndNumData % 10;
	FND_DispAllOff();
	GPIO_WritePort(FND_FONT_PORT, fndFont[digitData1]);
	FND_SetComPort(FND_COM_PORT, FND_COM_DIG_1, ON);
}

void FND_DispDigit_10() {
	uint16_t fndFont[16] = { 0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8,
			0x80, 0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e };
	//num �ڸ��� �и�
	uint16_t digitData10 = fndNumData / 10 % 10;
	FND_DispAllOff();
	GPIO_WritePort(FND_FONT_PORT, fndFont[digitData10]);
	FND_SetComPort(FND_COM_PORT, FND_COM_DIG_2, ON);
}

void FND_DispDigit_100() {
	uint16_t fndFont[16] = { 0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8,
			0x80, 0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e };
	uint16_t digitData100 = fndNumData / 100 % 10;
	FND_DispAllOff();
	GPIO_WritePort(FND_FONT_PORT, fndFont[digitData100]);
	GPIO_WritePin(FND_FONT_PORT, SEG_PIN_DP, dotpoint ? ON : OFF);
	FND_SetComPort(FND_COM_PORT, FND_COM_DIG_3, ON);
}

void FND_DispDigit_1000() {
	uint16_t fndFont[16] = { 0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8,
			0x80, 0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e };
	uint16_t digitData1000 = fndNumData / 1000 % 10;
	FND_DispAllOff();
	GPIO_WritePort(FND_FONT_PORT, fndFont[digitData1000]);
	FND_SetComPort(FND_COM_PORT, FND_COM_DIG_4, ON);
}

void FND_SetNum(uint16_t num) {
	fndNumData = num;
}

void FND_DispAllOn() {
	FND_SetComPort(FND_COM_PORT,
	FND_COM_DIG_1 | FND_COM_DIG_2 | FND_COM_DIG_3 | FND_COM_DIG_4, ON);
}

void FND_DispAllOff() {
	FND_SetComPort(FND_COM_PORT,
	FND_COM_DIG_1 | FND_COM_DIG_2 | FND_COM_DIG_3 | FND_COM_DIG_4, OFF);
}

void FND_DotPoint(int on) {
	if (on == 1) {
		dotpoint = 1;
	} else if (on == 0){
		dotpoint = 0;
}

}
