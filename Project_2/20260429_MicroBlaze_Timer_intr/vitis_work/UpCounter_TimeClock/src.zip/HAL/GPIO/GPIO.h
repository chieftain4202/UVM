

#ifndef SRC_HAL_GPIO_GPIO_H_
#define SRC_HAL_GPIO_GPIO_H_

#include <stdint.h>

typedef struct {
    uint32_t CR;
    uint32_t IDR;
    uint32_t ODR;
} GPIO_Typedef_t;


#define GPIOA_BASE_ADDR 0x44A00000
#define GPIOB_BASE_ADDR 0x44A10000


#define GPIOA ((GPIO_Typedef_t *)(GPIOA_BASE_ADDR))
#define GPIOB ((GPIO_Typedef_t *)(GPIOB_BASE_ADDR))

#define GPIO_PIN_0 0x01
#define GPIO_PIN_1 0x02
#define GPIO_PIN_2 0x04
#define GPIO_PIN_3 0x08
#define GPIO_PIN_4 0x10
#define GPIO_PIN_5 0x20
#define GPIO_PIN_6 0x40
#define GPIO_PIN_7 0x80

#define INPUT 	0x00
#define OUTPUT	0x01

#define RESET 	0
#define SET 	1

void GPIO_SetMode (GPIO_Typedef_t *GPIOx, uint32_t GPIO_Pin, int GPIO_Dir);
void GPIO_WritePin(GPIO_Typedef_t *GPIOx, uint32_t GPIO_Pin, int level);
void GPIO_WritePort (GPIO_Typedef_t *GPIOx, int data);
uint32_t GPIO_ReadPin(GPIO_Typedef_t *GPIOx, uint32_t GPIO_Pin);
uint32_t GPIO_ReadPort (GPIO_Typedef_t *GPIOx);

#endif /* SRC_HAL_GPIO_GPIO_H_ */
